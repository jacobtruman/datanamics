<?php
//ini_set ('display_errors', 'on');
session_start();

$root = 'D:/inetpub/support';
include_once($root.'/support_web/components/dbcon.php');
$db_name = "propinfo";
$tbl_name = "admin";
$count = 0;

$link = ado_connect( $dsn , $dtype);

$sql="SELECT * FROM ".$tbl_name." WHERE a_lgn = '".$_POST['myusername']."' AND a_pswd = '".$_POST['mypassword']."'";
$res = $link->Execute($sql);

if (!isset($res)){
}else{
	while (!$res->EOF){
		$count++;
	$res->MoveNext();
	}
ado_free_result( $res );
ado_close( $link );
}

if($count==1){
session_register("myusername");

if ($_POST['nextpage'] == ''){
	$url = '/support_web/forms/ResultsAdmin.php';
}else{
	$url = $_POST['nextpage'];
}
    echo "<script type='text/javascript'>location.href='".$url."';</script>"; 
}else{
	include ("login.php");
	echo "<center><font color='#FF0000'><b>Invalid Username or Password</b></font></center>";
}
?>