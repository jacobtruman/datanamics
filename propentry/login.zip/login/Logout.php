<?php
session_start();
session_destroy();
$url = '/support_web/propentry/login/login.php';
//if(headers_sent()) { 
   	echo "<script type='text/javascript'>location.href='".$url."';</script>"; 
/*}else{
	header("location:".$url);
}*/
?>